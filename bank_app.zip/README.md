# Mail Configuration
Username:	support@bjedcouncil.org
Password:	njSyXmf9AscFhxvHq37C
POP/IMAP Server:	mail.bjedcouncil.org
SMTP Server:	mail.bjedcouncil.org port 587

