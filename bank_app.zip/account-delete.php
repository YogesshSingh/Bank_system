<?php
include 'config/authCheck.php';

if(isset($_GET['userId'])){
    $userId = $_GET['userId'];
    $deleteBlog = "delete from users where uid='$userId'";
    
    if(mysqli_query($conn,$deleteBlog)){
        $success =  "Account deleted successfully";
        header('location: account-manage.php?success='.urlencode($success));
        exit;
    }else{
        echo "Error: ".mysqli_error($conn);
    }
}else{
    $error =  "Invalid entry";
    header("location:account-manage.php?error=".urldecode($error));
}