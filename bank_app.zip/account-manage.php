
<?php include 'config/authCheck.php';?>

<!DOCTYPE html>
<html lang="en" dir="ltr" class="light">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="shortcut icon" href="img/favicon.ico">
		<title>Elstar - HTML Tailwind Admin Template</title>

		<!-- Core CSS -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<!-- App Start-->
		<div id="root">
			<!-- App Layout-->
			<div class="app-layout-classic flex flex-auto flex-col">
				<div class="flex flex-auto min-w-0">
                    
                    <!-- Side Nav start-->
                    <?php include 'components/sidebar.php'; ?>
					<!-- Side Nav end-->


					<!-- Header Nav start-->
					<div class="flex flex-col flex-auto min-h-screen min-w-0 relative w-full">
                        
                        <header class="header border-b border-gray-200 dark:border-gray-700">
							<?php include 'components/header.php'; ?>
						</header>
						<!-- Popup start-->
						
						<!-- Popup end-->
						<div class="h-full flex flex-auto flex-col justify-between">
							<!-- Content start -->
							<main class="h-full">
								<div class="page-container relative h-full flex flex-auto flex-col px-4 sm:px-6 md:px-8 py-4 sm:py-6">
                                    <div class="container mx-auto">
                                        <div class="card adaptable-card">
                                            <div class="card-body">
                                                <div class="lg:flex items-center justify-between mb-4">
                                                    <h3 class="mb-4 lg:mb-0">Account Manage</h3>
                                                    <p>
                                                    <?php
                                                        if(isset($_GET['success'])) {
                                                            $successMessage = $_GET['success'];
                                                            $alertClass = '';
                                                            
                                                            if (strpos($successMessage, 'approved') !== false) {
                                                                $alertClass = 'alert-success'; 
                                                            } elseif (strpos($successMessage, 'rejected') !== false) {
                                                                $alertClass = 'alert-danger'; 
                                                            }
                                                        ?>
                                                        <p class="alert <?php echo $alertClass; ?>" style="float: right; margin-left: 60%;"><?php echo $successMessage; ?></p>
                                                        <?php
                                                        }
                                                        ?>
                                                    </p>
                                                </div>
                                                <div class="overflow-x-auto">
                                                    <table class="table-default table-hover data-table">
                                                        <thead>
                                                            <tr>
                                                                <th>#</th>
                                                                <th>Username</th>
                                                                <th>Email</th>
                                                                <th>Approved</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php 
                                                            $sqlQuery = "select * FROM users WHERE user_type != 0 ORDER BY uid DESC";
                                                            $result = mysqli_query($conn, $sqlQuery);
                                                            
                                                            if(mysqli_num_rows($result) > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {
                                                                    $uid = $row['uid'];
                                                                    $status = $row['status'];

                                                                if ($status == 0) {
                                                                    $status = '<a href="account-status.php?status=1&userId='.$uid.'">
                                                                                    <div class="flex items-center gap-2">
                                                                                        <span class="badge-dot bg-emerald-200"></span>
                                                                                        <span class="badge capitalize font-semibold text-emerald-200">Rejected</span>
                                                                                    </div>
                                                                                </a>';
                                                                }
                                                                if ($status == 1) {
                                                                    $status = '<a href="account-status.php?status=0&userId='.$uid.'">
                                                                                    <div class="flex items-center gap-2">
                                                                                        <span class="badge-dot bg-emerald-500"></span>
                                                                                        <span class="badge bg-emerald-500 mr-4 capitalize font-semibold text-emerald-200">Approved</span>
                                                                                    </div>
                                                                                </a>';
                                                                }

                                                            ?>
                                                            <tr>
                                                                <td>1</td>
                                                                <td>
                                                                    <div class="flex items-center">
                                                                        <span class="avatar avatar-rounded avatar-md">
                                                                            <img class="avatar-img avatar-rounded" src="img/avatars/thumb-1.jpg" loading="lazy">
                                                                        </span>
                                                                        <span class="ml-2 rtl:mr-2 font-semibold"><?php echo $row['username'];?></span>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <span class="capitalize"><?php echo $row['email'];?></span>
                                                                </td>
                                                                <td>
                                                                    
                                                                  <?php echo $status;?>
                                                                </td>
                                                                <td>
                                                                    <a href="account-delete.php?userId=<?php echo $uid;?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                                        <span class="cursor-pointer p-2 hover:text-red-500">
                                                                            <svg stroke="currentColor" fill="none" stroke-width="2" viewbox="0 0 24 24" aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </a>
                                                                </td>
                                                            <?php 
                                                             }
                                                            } else {
                                                                echo "<td colspan='20' style='text-align:center;'>No users found.</td>";
                                                            }?>
                                                             </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
							</main>
							<!-- Content end -->
							<footer class="footer flex flex-auto items-center h-16 px-4 sm:px-6 md:px-8">
								<div class="flex items-center justify-between flex-auto w-full">
									<span>Copyright © 2023 <span class="font-semibold">Elstar</span> All rights reserved.</span>
									<div>
										<a class="text-gray" href="#">Term &amp; Conditions</a>
										<span class="mx-2 text-muted"> | </span>
										<a class="text-gray" href="#">Privacy &amp; Policy</a>
									</div>
								</div>
							</footer>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Core Vendors JS -->
		<script src="js/vendors.min.js"></script>

		<!-- Other Vendors JS -->
        <script src="vendors/datatables/jquery.dataTables.min.js"></script>
        <script src="vendors/datatables/dataTables.custom-ui.min.js"></script>

		<!-- Page js -->
        <script src="js/pages/customers.js"></script>

		<!-- Core JS -->
		<script src="js/app.min.js"></script>
	</body>

</html>