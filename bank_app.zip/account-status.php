<?php
include 'config/authCheck.php';

if(isset($_GET['status']) && isset($_GET['userId'])) {
    $status = $_GET['status'];
    $userId = $_GET['userId'];
    $updateStatus = "UPDATE users SET status='$status' WHERE uid='$userId'";
    
    if(mysqli_query($conn, $updateStatus)) {
        if ($status == 1) {
            $successMsg = "User approved successfully";

            $getUserEmailQuery = "select email FROM users WHERE uid='$userId'";
            $result = mysqli_query($conn, $getUserEmailQuery);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $userEmail = $row['email'];

                // Send email notification
                include_once('send-notification-mail.php');
            }
        } elseif ($status == 0) {
            $successMsg = "Account rejected successfully";
        }

        header('location: account-manage.php?success='.urlencode($successMsg));
        exit;
    } else {
        $error = "Error updating user status: " . mysqli_error($conn);
        header("location: account-manage.php?error=".urlencode($error));
        exit; 
    }
} else {
    $error = "Invalid entry: Missing parameters";
    header("location: account-manage.php?error=".urlencode($error));
    exit; 
}
?>
