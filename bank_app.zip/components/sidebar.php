<?php
function isMenuItemActive($menuItemUrl) {
    $currentPageUrl = basename($_SERVER['PHP_SELF']);
    return (strpos($currentPageUrl, $menuItemUrl) !== false) ? 'menu-item menu-item-active' : '';
}
?>
<div class="side-nav side-nav-light side-nav-expand">
    <div class="side-nav-header">
        <div class="logo px-6">
            <img src="img/logo/logo-light-full.png" alt="Elstar logo">
        </div>
    </div>
    <div class="side-nav-content relative side-nav-scroll">
        <nav class="menu menu-transparent px-4 pb-4">
            <div class="menu-group">
                <div class="menu-title">Apps</div>
                <ul>
                    <li class="menu-collapse">
                        <li data-menu-item="classic-welcome" class="menu-item menu-item-single mb-2 <?php echo isMenuItemActive('dashboard.php'); ?>">
                            <a class="menu-item-link" href="dashboard.php">
                                <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <span class="menu-item-text">Dashboard</span>
                            </a>
                        </li>
                    </li>
                    <?php if(isset($_SESSION['user_type']) && $_SESSION['user_type'] == 0): ?>
                    <li class="menu-collapse">
                        <li data-menu-item="classic-welcome" class="menu-item menu-item-single mb-2 <?php echo isMenuItemActive('account-manage.php'); ?>">
                            <a class="menu-item-link" href="account-manage.php">
                                <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="menu-item-text">Account Management</span>
                            </a>
                        </li>
                    </li>
                    <?php endif; ?>
                    <li class="menu-collapse">
                        <li data-menu-item="classic-welcome" class="menu-item menu-item-single mb-2 <?php echo isMenuItemActive('trans-manage.php'); ?>">
                            <a class="menu-item-link" href="trans-manage.php">
                                <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                                </svg>
                                <span class="menu-item-text">Transaction Management  </span>
                            </a>
                        </li>
                    </li>
                    <li class="menu-collapse">
                        <li data-menu-item="classic-welcome" class="menu-item menu-item-single mb-2 <?php echo isMenuItemActive('report-manage.php'); ?>">
                            <a class="menu-item-link" href="report-manage.php">
                                <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                                </svg>
                                <span class="menu-item-text">Report Management  </span>
                            </a>
                        </li>
                    </li>
                </ul>
            </div>
            <!-- <div class="menu-group">
                <div class="menu-title">UI Components</div>
                <ul>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"></path>
                            </svg>
                            <span class="menu-item-text">Common</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-button" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-button.html.htm">
                                    <span>Button</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-grid" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-grid.html.htm">
                                    <span>Grid</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-typography" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-typography.html.htm">
                                    <span>Typography</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-icons" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-icons.html.htm">
                                    <span>Icons</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
                            </svg>
                            <span class="menu-item-text">Feedback</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-alert" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-alert.html.htm">
                                    <span>Alert</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-dialog" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-dialog.html.htm">
                                    <span>Dialog</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-drawer" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-drawer.html.htm">
                                    <span>Drawer</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-progress" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-progress.html.htm">
                                    <span>Progress</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-skeleton" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-skeleton.html.htm">
                                    <span>Skeleton</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-spinner" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-spinner.html.htm">
                                    <span>Spinner</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-toast" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-toast.html.htm">
                                    <span>Toast</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                            </svg>
                            <span class="menu-item-text">Data Display</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-avatar" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-avatar.html.htm">
                                    <span>Avatar</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-badge" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-badge.html.htm">
                                    <span>Badge</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-card" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-card.html.htm">
                                    <span>Card</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-table" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-table.html.htm">
                                    <span>Table</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-tag" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-tag.html.htm">
                                    <span>Tag</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-timeline" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-timeline.html.htm">
                                    <span>Timeline</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-tooltip" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-tooltip.html.htm">
                                    <span>Tooltip</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            <span class="menu-item-text">Forms</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-checkbox" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-checkbox.html.htm">
                                    <span>Checkbox</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-date-picker" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-date-picker.html.htm">
                                    <span>Date Picker</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-form" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-form.html.htm">
                                    <span>Form</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-input" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-input.html.htm">
                                    <span>Input</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-input-group" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-input-group.html.htm">
                                    <span>Input Group</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-radio" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-radio.html.htm">
                                    <span>Radio</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-segment" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-segment.html.htm">
                                    <span>Segment</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-select" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-select.html.htm">
                                    <span>Select</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-switcher" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-switcher.html.htm">
                                    <span>Switcher</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                            </svg>
                            <span class="menu-item-text">Navigation</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-dropdown" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-dropdown.html.htm">
                                    <span>Dropdown</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-menu" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-menu.html.htm">
                                    <span>Menu</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-pagination" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-pagination.html.htm">
                                    <span>Pagination</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-steps" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-steps.html.htm">
                                    <span>Steps</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-tabs" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-tabs.html.htm">
                                    <span>Tabs</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"></path>
                            </svg>
                            <span class="menu-item-text">Graph</span>
                        </div>
                        <ul>
                            <li data-menu-item="classic-chart" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-chart.html.htm">
                                    <span>Charts</span>
                                </a>
                            </li>
                            <li data-menu-item="classic-maps" class="menu-item">
                                <a class="h-full w-full flex items-center" href="classic-maps.html.htm">
                                    <span>Maps</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="menu-group">
                <div class="menu-title">Authentication</div>
                <ul>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                            </svg>
                            <span class="menu-item-text">Sign In</span>
                        </div>
                        <ul>
                            <li data-menu-item="signin-simple" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signin-simple.html.htm">
                                    <span>Simple</span>
                                </a>
                            </li>
                            <li data-menu-item="signin-side" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signin-side.html.htm">
                                    <span>Side</span>
                                </a>
                            </li>
                            <li data-menu-item="signin-cover" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signin-cover.html.htm">
                                    <span>Cover</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                            </svg>
                            <span class="menu-item-text">Sign Up</span>
                        </div>
                        <ul>
                            <li data-menu-item="signup-simple" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signup-simple.html.htm">
                                    <span>Simple</span>
                                </a>
                            </li>
                            <li data-menu-item="signup-side" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signup-side.html.htm">
                                    <span>Side</span>
                                </a>
                            </li>
                            <li data-menu-item="signup-cover" class="menu-item">
                                <a class="h-full w-full flex items-center" href="signup-cover.html.htm">
                                    <span>Cover</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                            </svg>
                            <span class="menu-item-text">Forgot Password</span>
                        </div>
                        <ul>
                            <li data-menu-item="forget-password-simple" class="menu-item">
                                <a class="h-full w-full flex items-center" href="forget-password-simple.html.htm">
                                    <span>Simple</span>
                                </a>
                            </li>
                            <li data-menu-item="forget-password-side" class="menu-item">
                                <a class="h-full w-full flex items-center" href="forget-password-side.html.htm">
                                    <span>Side</span>
                                </a>
                            </li>
                            <li data-menu-item="forget-password-cover" class="menu-item">
                                <a class="h-full w-full flex items-center" href="forget-password-cover.html.htm">
                                    <span>Cover</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-collapse">
                        <div class="menu-collapse-item">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"></path>
                            </svg>
                            <span class="menu-item-text">Reset Password</span>
                        </div>
                        <ul>
                            <li data-menu-item="reset-password-simple" class="menu-item">
                                <a class="h-full w-full flex items-center" href="reset-password-simple.html.htm">
                                    <span>Simple</span>
                                </a>
                            </li>
                            <li data-menu-item="reset-password-side" class="menu-item">
                                <a class="h-full w-full flex items-center" href="reset-password-side.html.htm">
                                    <span>Side</span>
                                </a>
                            </li>
                            <li data-menu-item="reset-password-cover" class="menu-item">
                                <a class="h-full w-full flex items-center" href="reset-password-cover.html.htm">
                                    <span>Cover</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="menu-group">
                <div class="menu-title menu-title-transparent">
                    Pages
                </div>
                <ul>
                    <li data-menu-item="classic-welcome" class="menu-item menu-item-single mb-2">
                        <a class="menu-item-link" href="classic-welcome.html.htm">
                            <svg class="menu-item-icon" stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11"></path>
                            </svg>
                            <span class="menu-item-text">Welcome</span>
                        </a>
                    </li>
                    <li data-menu-item="classic-access-denied" class="menu-item menu-item-single mb-2">
                        <a class="menu-item-link" href="classic-access-denied.html.htm">
                            <span class="menu-item-icon">
                                <svg stroke="currentColor" fill="none" stroke-width="0" viewbox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path>
                                </svg>
                            </span>
                            <span class="menu-item-text">Access Denied</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="menu-group">
                <div class="menu-title menu-title-transparent">
                    Guide
                </div>
                <ul>
                    <li data-menu-item="classic-documentation" class="menu-item menu-item-single mb-2">
                        <a class="menu-item-link" href="http://www.themenate.net/elstar-html-doc" target="_blank">
                            <span class="menu-item-icon">
                                <svg stroke="currentColor" fill="none" stroke-width="2" viewbox="0 0 24 24" aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                </svg>
                            </span>
                            <span class="menu-item-text">Documentation</span>
                        </a>
                    </li>
                </ul>
            </div> -->
        </nav>	
    </div>
</div>