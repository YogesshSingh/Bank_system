<?php 
session_start();

include 'database/dbConnect.php';

if(!isset($_SESSION['username']) && !isset($_SESSION['user_type'])){
    header("Location:index.php");
    exit;
}

if (!isset($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}
?>