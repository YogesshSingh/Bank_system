<?php include 'config/authCheck.php';?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="light">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="shortcut icon" href="img/favicon.ico">
		<title>Elstar - HTML Tailwind Admin Template</title>

		<!-- Core CSS -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<!-- App Start-->
		<div id="root">
			<!-- App Layout-->
			<div class="app-layout-classic flex flex-auto flex-col">
				<div class="flex flex-auto min-w-0">
					
					<!-- Side Nav start-->
					<?php include 'components/sidebar.php'; ?>
					<!-- Side Nav end-->

					<!-- Header Nav start-->
					<div class="flex flex-col flex-auto min-h-screen min-w-0 relative w-full">
						
						<header class="header border-b border-gray-200 dark:border-gray-700">
							<?php include 'components/header.php'; ?>
						</header>
						
						<div class="h-full flex flex-auto flex-col justify-between">
							<!-- Content start -->
							<main class="h-full">
								<div class="page-container relative h-full flex flex-auto flex-col px-4 sm:px-6 md:px-8 py-4 sm:py-6">
                                    <div class="container mx-auto">
                                        <h3 class="mb-4">Dashboard</h3>
                                        <div class="grid grid-cols-1 xl:grid-cols-11 gap-4 mt-4">
                                            <div class="card card-layout-frame 2xl:col-span-3 xl:col-span-4">
                                                <div class="card-body">
                                                    <div class="flex items-center justify-between">
                                                        <h4>Recent Transaction</h4>
                                                    </div>
                                                    <div class="mt-6">
                                                        <div class="mb-6">
															<?php 
															$userType = $_SESSION['user_type'];
															$userId = $_SESSION['uid'];
															
															if($userType == 0 || isset($userId)){
																$sqlQuery = "SELECT u.uid, u.username, u.user_type, COUNT(t.trans_id) AS transaction_count
																			 FROM users u 
																			 LEFT JOIN transaction t ON u.uid = t.uid
																			 WHERE u.user_type = '$userType' AND u.uid = '$userId'
																			 GROUP BY u.uid, u.username, u.user_type";
															} else {
																$sqlQuery = "SELECT u.uid, u.username, u.user_type, COUNT(t.trans_id) AS transaction_count
																			 FROM users u 
																			 LEFT JOIN transaction t ON u.uid = t.uid
																			 GROUP BY u.uid, u.username, u.user_type";
															}
															
															$result = mysqli_query($conn, $sqlQuery);
															
															// Check if there are any rows returned
															if(mysqli_num_rows($result) > 0) {
																while($rows = mysqli_fetch_array($result)) {
																	echo "<p class='mb-4'>Transaction Count for User ".$rows['username'].": ".$rows['transaction_count']."</p>";
																}
															} else {
																echo "<p>No transactions found.</p>";
															}
															
															?>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
							</main>
							<!-- Content end -->
							<footer class="footer flex flex-auto items-center h-16 px-4 sm:px-6 md:px-8">
								<div class="flex items-center justify-between flex-auto w-full">
									<span>Copyright © 2023 <span class="font-semibold">Elstar</span> All rights reserved.</span>
									<div>
										<a class="text-gray" href="#">Term &amp; Conditions</a>
										<span class="mx-2 text-muted"> | </span>
										<a class="text-gray" href="#">Privacy &amp; Policy</a>
									</div>
								</div>
							</footer>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Core Vendors JS -->
		<script src="js/vendors.min.js"></script>

		<!-- Other Vendors JS -->
        <script src="vendors/apexcharts/apexcharts.js"></script>

		<!-- Page js -->
        <script src="js/pages/portfolio.js"></script>

		<!-- Core JS -->
		<script src="js/app.min.js"></script>
</body>

</html>