/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/es/pages/maps-demo.js":
/*!***********************************!*\
  !*** ./src/es/pages/maps-demo.js ***!
  \***********************************/
/***/ (() => {

eval("$('#world-map-demo').vectorMap(\r\n    {\r\n        map: 'world_en',\r\n        backgroundColor: 'transparent',\r\n        color: '#f3f4f6',\r\n        hoverOpacity: 0.7,\r\n        selectedColor: '#666666',\r\n        showTooltip: true,\r\n        colors: {\r\n            us: '#3b82f6',\r\n            br: '#3b82f6',\r\n            au: '#3b82f6',\r\n        },\r\n    }\r\n)\r\n\r\n$('#usa-map-demo').vectorMap(\r\n    {\r\n        map: 'usa_en',\r\n        backgroundColor: 'transparent',\r\n        color: '#f3f4f6',\r\n        hoverOpacity: 0.7,\r\n        selectedColor: '#666666',\r\n        showTooltip: true,\r\n    }\r\n)\n\n//# sourceURL=webpack://elstar/./src/es/pages/maps-demo.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/es/pages/maps-demo.js"]();
/******/ 	
/******/ })()
;