<?php
session_start();
include 'database/dbConnect.php';

if (isset($_SESSION['token'])) {
    $token = $_SESSION['token'];

    $sqlQuery = "update users SET token='' WHERE token='$token'";
    if (mysqli_query($conn, $sqlQuery)) {

        unset($_SESSION['token']);
        session_destroy();
        
        header("Location: index.php?msg=" . urlencode("You have been logged out successfully."));
        exit;
    } else {
        echo "Error deleting token: " . mysqli_error($conn);
    }
} else {
    header("Location: index.php");
    exit;
}
?>
