
<?php include 'config/authCheck.php';?>

<!DOCTYPE html>
<html lang="en" dir="ltr" class="light">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="shortcut icon" href="img/favicon.ico">
		<title>Elstar - HTML Tailwind Admin Template</title>

		<!-- Core CSS -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<!-- App Start-->
		<div id="root">
			<!-- App Layout-->
			<div class="app-layout-classic flex flex-auto flex-col">
				<div class="flex flex-auto min-w-0">
                    
                    <!-- Side Nav start-->
                    <?php include 'components/sidebar.php'; ?>
					<!-- Side Nav end-->


					<!-- Header Nav start-->
					<div class="flex flex-col flex-auto min-h-screen min-w-0 relative w-full">
                        
                        <header class="header border-b border-gray-200 dark:border-gray-700">
							<?php include 'components/header.php'; ?>
						</header>
						<!-- Popup start-->
						
						<!-- Popup end-->
						<div class="h-full flex flex-auto flex-col justify-between">
							<!-- Content start -->
							<main class="h-full">
								<div class="page-container relative h-full flex flex-auto flex-col px-4 sm:px-6 md:px-8 py-4 sm:py-6">
                                    <div class="container mx-auto">
                                        <div class="card adaptable-card">
                                            <div class="card-body">
                                                <div class="lg:flex items-center justify-between mb-4">
                                                    <h3 class="mb-4 lg:mb-0">Report Manage </h3>
                                                   
                                                    <?php
                                                        if(isset($_GET['success'])) {
                                                            $successMessage = $_GET['success'];
                                                            $alertClass = '';
                                                            
                                                            if (strpos($successMessage, 'approved') !== false) {
                                                                $alertClass = 'alert-success'; 
                                                            } elseif (strpos($successMessage, 'rejected') !== false) {
                                                                $alertClass = 'alert-danger'; 
                                                            }
                                                        ?>
                                                        <p class="alert <?php echo $alertClass; ?>" style="float: right; margin-left: 60%;"><?php echo $successMessage; ?></p>
                                                        <?php
                                                        }
                                                        ?>
                                                    </p>
                                                </div>
                                                <?php 
                                                
                                                ?>
                                                <form method="post">
                                                    <div class="lg:flex items-center justify-between mb-4">
                                                        <div>
                                                            <div class="input-group mb-4">
                                                                <span class="input-wrapper">
                                                                    <input datepicker class="input pr-8" type="text" placeholder="Start Date" name="start_date" readonly="" autocomplete="off" value="">
                                                                    <div class="input-suffix-end">
                                                                        <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" class="text-lg" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                                                        </svg>
                                                                    </div>
                                                                </span>
                                                                <div class="input-addon">To</div>
                                                                <span class="input-wrapper">
                                                                    <input datepicker class="input pr-8" type="text" placeholder="End Date" name="end_date" readonly="" autocomplete="off" value="">
                                                                    <div class="input-suffix-end">
                                                                        <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" class="text-lg" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                                                        </svg>
                                                                    </div>
                                                                </span>
                                                                <div class="input-group mb-0">
                                                                    <input class="input" type="time" name="start_time">
                                                                    <div class="input-addon">to</div>
                                                                    <input class="input" type="time" name="end_time">
                                                                </div>
                                                                <button name="submit" type="submit" class="btn bg-sky-50 dark:bg-sky-500 dark:bg-opacity-20 hover:bg-sky-100 dark:hover:bg-sky-500 dark:hover:bg-opacity-30 active:bg-sky-200 dark:active:bg-sky-500 dark:active:bg-opacity-40 text-sky-800 dark:text-sky-50 mr-2">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="overflow-x-auto">
                                                    <table class="table-default table-hover data-table">
                                                        <thead>
                                                            <tr>
                                                                <th>#</th>
                                                                <th>Username</th>
                                                                <th>Amount</th>
                                                                <th>Date</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php 

                                                            $userType = $_SESSION['user_type'];
                                                            $userId = $_SESSION['uid']; 

                                                            if($userType == 0 || isset($userId)){
                                                                            $sqlQuery = "SELECT u.uid, u.username, u.user_type, t.* 
                                                                            FROM users u, transaction t 
                                                                            WHERE u.uid = t.uid AND u.user_type = $userType AND u.uid = $userId";
                                                            } else {
                                                                $sqlQuery = "SELECT u.uid, u.username, u.user_type, t.* 
                                                                            FROM users u, transaction t 
                                                                            WHERE u.uid = t.uid";
                                                            }

                                                            //start date or end date report
                                                            if(isset($_POST['start_date']) && $_POST['start_date'] != "") {
                                                                $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
                                                                $start_date_formatted = date('Y-m-d', strtotime($start_date));
                                                                $sqlQuery .= " and (DATE(t.created_at) = '$start_date_formatted'";
                                                            }

                                                            if(isset($_POST['end_date']) && $_POST['end_date'] != "") {
                                                                $end_date = mysqli_real_escape_string($conn, $_POST['end_date']);
                                                                $end_date_formatted = date('Y-m-d', strtotime($end_date));
                                                                $sqlQuery .= " OR DATE(t.created_at) = '$end_date_formatted')";
                                                            }

                                                            //hr report
                                                            if(isset($_POST['start_time']) && $_POST['start_time'] != "") {
                                                                $start_time = mysqli_real_escape_string($conn, $_POST['start_time']);
                                                                $sqlQuery .= " AND TIME(t.created_at) >= '$start_time'";
                                                            }
                                                            
                                                            // Check if end_time is provided
                                                            if(isset($_POST['end_time']) && $_POST['end_time'] != "") {
                                                                $end_time = mysqli_real_escape_string($conn, $_POST['end_time']);
                                                                $sqlQuery .= " AND TIME(t.created_at) <= '$end_time'";
                                                            }

                                                            $i=1;
                                                            $sqlQuery .= " ORDER BY t.trans_id";
                                                            $result = mysqli_query($conn, $sqlQuery);
                                                            
                                                            if(mysqli_num_rows($result) > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {
                                                                    $tid = $row['trans_id'];
                                                                    $date = date("d M y", strtotime($row['created_at']));

                                                            ?>
                                                            <tr>
                                                                <td><?php echo $i++;?></td>
                                                                <td>
                                                                    <div class="flex items-center">
                                                                        
                                                                        <span class="avatar avatar-rounded avatar-md">
                                                                            <img class="avatar-img avatar-rounded" src="img/avatars/thumb-1.jpg" loading="lazy">
                                                                        </span>
                                                                        <span class="ml-2 rtl:mr-2 font-semibold"><?php echo $row['username'];?></span>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <span class="capitalize"><?php echo $row['amount'];?></span>
                                                                </td>
                                                                <td><?php echo $date;?></td>
                                                                <td>
                                                                    <div class="flex justify text-lg">
                                                                        <span class="cursor-pointer p-2 hover:text-indigo-600">
                                                                            <a href="update-transaction.php?transId=<?php echo $tid; ?>">
                                                                                <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                        <span class="cursor-pointer p-2 hover:text-red-500">
                                                                            <a href="tran-delete.php?transId=<?php echo $tid;?>" onclick="return confirm('Are you sure you want to delete this transaction?');">
                                                                                <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                                                </svg>
                                                                            </a>
                                                                        </span>
                                                                    </div>
                                                                </td>
                                                            <?php 
                                                             }
                                                            } else {
                                                                echo "<td colspan='20' style='text-align:center;'>No users found.</td>";
                                                            }?>
                                                             </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
							</main>
							<!-- Content end -->
							<footer class="footer flex flex-auto items-center h-16 px-4 sm:px-6 md:px-8">
								<div class="flex items-center justify-between flex-auto w-full">
									<span>Copyright © 2023 <span class="font-semibold">Elstar</span> All rights reserved.</span>
									<div>
										<a class="text-gray" href="#">Term &amp; Conditions</a>
										<span class="mx-2 text-muted"> | </span>
										<a class="text-gray" href="#">Privacy &amp; Policy</a>
									</div>
								</div>
							</footer>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Core Vendors JS -->
		<script src="js/vendors.min.js"></script>

		<!-- Other Vendors JS -->
        <script src="vendors/datatables/jquery.dataTables.min.js"></script>
        <script src="vendors/datatables/dataTables.custom-ui.min.js"></script>

		<!-- Page js -->
        <script src="js/pages/customers.js"></script>

		<!-- Core JS -->
		<script src="js/app.min.js"></script>
	</body>

</html>