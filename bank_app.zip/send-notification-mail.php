<?php

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

# Mail Configuration
// Username:	support@bjedcouncil.org
// Password:	njSyXmf9AscFhxvHq37C
// POP/IMAP Server:	mail.bjedcouncil.org
// SMTP Server:	mail.bjedcouncil.org port 587

try {
    $mail->isSMTP();
    $mail->Host = 'mail.bjedcouncil.org';
    $mail->SMTPAuth = true;
    $mail->Username = 'support@bjedcouncil.org';
    $mail->Password = 'njSyXmf9AscFhxvHq37C';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
    $mail->Port = 587;
    $mail->SMTPDebug = 0; 

    $mail->setFrom('support@bjedcouncil.org', 'BJED Council Support'); 
    $mail->addAddress($userEmail, $username);

    $mail->isHTML(true);
    $mail->Subject = 'Your Account is Approved';
    $mail->Body = 'Your Account is Approved';

    $mail->send();
    // $_SESSION['msg'] = "Registration successful. Please check your email for confirmation.";
    // header("Location: login.php");
    // exit;
} catch (Exception $e) {
    $error[] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
