
<?php include 'config/authCheck.php';?>

<!DOCTYPE html>
<html lang="en" dir="ltr" class="light">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<link rel="shortcut icon" href="img/favicon.ico">
		<title>Elstar - HTML Tailwind Admin Template</title>

		<!-- Core CSS -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
        <style>
            .hidden {
                display: none;
            }
        </style>
	</head>
	<body>
		<!-- App Start-->
		<div id="root">
			<!-- App Layout-->
			<div class="app-layout-classic flex flex-auto flex-col">
				<div class="flex flex-auto min-w-0">
                    
                    <!-- Side Nav start-->
                    <?php include 'components/sidebar.php'; ?>
					<!-- Side Nav end-->


					<!-- Header Nav start-->
					<div class="flex flex-col flex-auto min-h-screen min-w-0 relative w-full">
                        
                        <header class="header border-b border-gray-200 dark:border-gray-700">
							<?php include 'components/header.php'; ?>
						</header>
						<!-- Popup start-->
						
						<!-- Popup end-->
						<div class="h-full flex flex-auto flex-col justify-between">
							<!-- Content start -->
							<main class="h-full">
								<div class="page-container relative h-full flex flex-auto flex-col px-4 sm:px-6 md:px-8 py-4 sm:py-6">
                                    <div class="container mx-auto">
                                        <h3 class="mb-4">Add New </h3>
                                        <?php 
                                        $errors = [];
                                        if (isset($_POST['submit'])) {

                                            if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['token']) {
                                                $errors[] = "Invalid token. Transaction failed.";
                                            }

                                            $note = mysqli_real_escape_string($conn, $_POST['note']);
                                            $trans_type = mysqli_real_escape_string($conn, $_POST['trans_type']);
                                            $amount = mysqli_real_escape_string($conn, $_POST['amount']);
                                            $userId = $_SESSION['uid'];
                                            $userType = $_SESSION['user_type'];

                                            
                                                if ($trans_type === 'cheque' && isset($_FILES["chequeFile"])) {
                                                    if ($_FILES["chequeFile"]["error"] == UPLOAD_ERR_OK) {
                                                        $target_dir = "uploads/";
                                                        $tmp_name = $_FILES["chequeFile"]["tmp_name"];
                                                        $target_file = $target_dir . uniqid() . "_" . basename($_FILES["chequeFile"]["name"]);
                                                        if (!move_uploaded_file($_FILES['chequeFile']["tmp_name"], $target_file)) {
                                                            $errors[] = "Could not move uploaded file";
                                                        }
                                                    }
                                                }

                                                if (!preg_match('/^\d+(\.\d{1,2})?$/', $amount)) {
                                                    $errors[] = "Invalid input , only numbers allowed";
                                                }
                                                
                                                if (empty($errors)) {
                                                    if ($trans_type === 'cheque') {
                                                        $query = "insert INTO transaction (uid, trans_type, amount, user_type, note, cheque, status) VALUES ('$userId', '$trans_type', '$amount', '$userType', '$note', '$target_file', 'pending')";
                                                    } else {
                                                        $query = "insert INTO transaction (uid, amount, trans_type, user_type, note) VALUES ('$userId', '$amount', '$trans_type', '$userType', '$note')";
                                                    }
                                            
                                                    if (mysqli_query($conn, $query)) {
                                                        $messages = [
                                                            'cheque' => 'Cheque submitted. Waiting for approval.',
                                                            'credit' => 'Credit transaction recorded successfully.',
                                                            'debit' => 'Debit transaction recorded successfully.'
                                                        ];
                                            
                                                        if (array_key_exists($trans_type, $messages)) {
                                                            echo "<div class='alert alert-success'>" . $messages[$trans_type] . "</div>";
                                                        } else {
                                                            echo "<div class='alert alert-success'>Transaction record added successfully</div>";
                                                        }
                                                    } else {
                                                        echo "Error: " . mysqli_error($conn);
                                                    }
                                                } else {
                                                    foreach ($errors as $error) {
                                                        echo '<div class="alert alert-danger"><ul><li>' . $error . '</li></ul></div>';
                                                    }
                                                }
                                            
                                        }
                                        
                                        
                                        ?>                                        
                                        <form method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
                                            <div class="form-container vertical">
                                                <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                                                    <div class="lg:col-span-2">
                                                        <div class="card adaptable-card !border-b pb-6 py-4 rounded-br-none rounded-bl-none">
                                                            <div class="card-body">
                                                                <div class="col-span-1">
                                                                    <div class="form-item vertical">
                                                                        <label class="form-label mb-2">Transaction Type</label>
                                                                        <div>
                                                                            <select class="input" name="trans_type" id="trans_type" onchange="toggleInputs()">
                                                                                <option selected="">Select...</option>
                                                                                <option value="credit">Credit</option>
                                                                                <option value="debit">Debit</option>
                                                                                <option value="cheque">Cheque</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-item vertical" id="amountContainer">
                                                                    <label class="form-label mb-2" for="amount">Amount</label>
                                                                    <input class="input" type="text" name="amount" id="amount" autocomplete="off" placeholder="Enter an amount" value="">
                                                                </div>
                                                                <div class="file-input-container hidden" id="fileInputContainer">
                                                                    <label class="form-label mb-2" for="chequeFile">Upload Cheque</label>
                                                                    <input class="input" type="file" name="chequeFile" id="chequeFile">
                                                                </div>
                                                                <div class="form-item vertical">
                                                                    <label class="form-label mb-2">Note: </label>
                                                                    <textarea class="input input-textarea" type="text" name="note" id="amount" autocomplete="off" placeholder="@" value=""></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="stickyFooter" class="sticky -bottom-1 -mx-8 px-8 flex items-center justify-end py-4">
                                                    <div class="md:flex items-center">
                                                        <button class="btn btn-default btn-sm ltr:mr-2 rtl:ml-2" type="reset">Discard</button>
                                                        <button class="btn btn-solid btn-sm" type="submit" name="submit">
                                                            <span class="flex items-center justify-center">
                                                                <span class="text-lg">
                                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewbox="0 0 1024 1024" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M893.3 293.3L730.7 130.7c-7.5-7.5-16.7-13-26.7-16V112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V338.5c0-17-6.7-33.2-18.7-45.2zM384 184h256v104H384V184zm456 656H184V184h136v136c0 17.7 14.3 32 32 32h320c17.7 0 32-14.3 32-32V205.8l136 136V840zM512 442c-79.5 0-144 64.5-144 144s64.5 144 144 144 144-64.5 144-144-64.5-144-144-144zm0 224c-44.2 0-80-35.8-80-80s35.8-80 80-80 80 35.8 80 80-35.8 80-80 80z"></path>
                                                                    </svg>
                                                                </span>
                                                                <span class="ltr:ml-1 rtl:mr-1">Save</span>
                                                            </span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>    
                                </div>
							</main>
							<!-- Content end -->
							<footer class="footer flex flex-auto items-center h-16 px-4 sm:px-6 md:px-8">
								<div class="flex items-center justify-between flex-auto w-full">
									<span>Copyright © 2023 <span class="font-semibold">Elstar</span> All rights reserved.</span>
									<div>
										<a class="text-gray" href="#">Term &amp; Conditions</a>
										<span class="mx-2 text-muted"> | </span>
										<a class="text-gray" href="#">Privacy &amp; Policy</a>
									</div>
								</div>
							</footer>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Core Vendors JS -->
		<script src="js/vendors.min.js"></script>

		<!-- Other Vendors JS -->
        <script src="vendors/datatables/jquery.dataTables.min.js"></script>
        <script src="vendors/datatables/dataTables.custom-ui.min.js"></script>

		<!-- Page js -->
        <script src="js/pages/customers.js"></script>

		<!-- Core JS -->
		<script src="js/app.min.js"></script>
        <script>
            function toggleInputs() {
                const transType = document.getElementById('trans_type').value;
                const amountContainer = document.getElementById('amountContainer');
                const fileInputContainer = document.getElementById('fileInputContainer');

                if (transType === 'cheque') {
                    amountContainer.classList.add('hidden');
                    fileInputContainer.classList.remove('hidden');
                } else {
                    amountContainer.classList.remove('hidden');
                    fileInputContainer.classList.add('hidden');
                }
            }

            document.addEventListener('DOMContentLoaded', function() {
                toggleInputs();
            });
        </script>
	</body>

</html>