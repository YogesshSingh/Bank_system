<?php include 'config/authCheck.php';

if(isset($_POST['newStatus']) && isset($_POST['transId'])) {
    $newStatus = $_POST['newStatus'];
    $transId = $_POST['transId'];

    // Update status in the database
    $updateQuery = "UPDATE transaction SET status='$newStatus' WHERE trans_id='$transId'";
    mysqli_query($conn, $updateQuery);

    // Return a response if needed
    echo "Status updated successfully.";
} else {
    echo "Error: Missing parameters.";
}
?>
